export interface YearGoal {
  id: string;
  title: string;
  why: string;
  successCriteria: string;
  createdAt: string;
}

export interface QuarterPlan {
  id: string;
  year: number;
  quarter: number; // 1, 2, 3, 4
  primaryGoalId: string; // Links to YearGoal
  outcome: string;
  keyTasks: string[]; // 3-5 key tasks
  isLocked: boolean;
  createdAt: string;
}

export type EffortLevel = 'Low' | 'Medium' | 'Deep Work';

export interface DailyLog {
  id: string;
  date: string; // ISO Date string YYYY-MM-DD
  description: string;
  linkedQuarterGoalId: string | null; // Null implies distraction if we are strictly following the rule, or we can use a boolean flag.
  isDistraction: boolean;
  effort: EffortLevel;
  proactiveness: number; // 1-5
  createdAt: string;
}

export interface WeeklyReflection {
  id: string;
  weekStartDate: string; // ISO Date YYYY-MM-DD representing the Monday of the week
  movedForward: string;
  wastedTime: string;
  stopDoing: string;
  createdAt: string;
}

export interface AppState {
  yearGoals: YearGoal[];
  quarterPlans: QuarterPlan[];
  dailyLogs: DailyLog[];
  reflections: WeeklyReflection[];
}

export type ViewState = 'dashboard' | 'log' | 'goals' | 'reflection';
