import React, { useState } from 'react';
import { YearGoal, QuarterPlan } from '../types';
import { getCurrentQuarter } from '../services/storage';
import { Compass, CheckCircle2, AlertCircle } from 'lucide-react';

interface Props {
  yearGoals: YearGoal[];
  onSave: (plan: QuarterPlan) => void;
}

export const QuarterSetup: React.FC<Props> = ({ yearGoals, onSave }) => {
  const { year, quarter } = getCurrentQuarter();
  const [selectedGoalId, setSelectedGoalId] = useState<string>('');
  const [outcome, setOutcome] = useState('');
  const [tasks, setTasks] = useState<string[]>(['', '', '']);

  const handleTaskChange = (idx: number, val: string) => {
    const newTasks = [...tasks];
    newTasks[idx] = val;
    setTasks(newTasks);
  };

  const canSubmit = selectedGoalId && outcome.trim().length > 0 && tasks.filter(t => t.trim()).length >= 1;

  const handleSave = () => {
    if (!canSubmit) return;

    const plan: QuarterPlan = {
      id: crypto.randomUUID(),
      year,
      quarter,
      primaryGoalId: selectedGoalId,
      outcome,
      keyTasks: tasks.filter(t => t.trim()),
      isLocked: true,
      createdAt: new Date().toISOString(),
    };
    onSave(plan);
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="text-center mb-10">
        <div className="inline-flex items-center justify-center px-4 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-sm font-semibold mb-4">
          Q{quarter} {year} Planning
        </div>
        <h1 className="text-3xl font-bold text-stone-900 mb-2">Focus Your Quarter</h1>
        <p className="text-stone-500">Select ONE primary goal to advance significantly this quarter.</p>
      </div>

      <div className="space-y-8">
        {/* Step 1: Select Goal */}
        <div className="space-y-3">
          <label className="text-sm font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">1</span>
            Select Primary Goal
          </label>
          <div className="grid gap-3">
            {yearGoals.map(goal => (
              <button
                key={goal.id}
                onClick={() => setSelectedGoalId(goal.id)}
                className={`text-left p-4 rounded-xl border-2 transition-all ${
                  selectedGoalId === goal.id 
                  ? 'border-emerald-600 bg-emerald-50 ring-1 ring-emerald-600' 
                  : 'border-stone-200 bg-white hover:border-stone-300'
                }`}
              >
                <div className="font-semibold text-stone-900">{goal.title}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Step 2: Define Outcome */}
        <div className="space-y-3">
          <label className="text-sm font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">2</span>
            Define Quarter Outcome
          </label>
          <div className="relative">
             <input 
              className="w-full p-4 border border-stone-300 rounded-xl focus:ring-2 focus:ring-emerald-800 focus:outline-none"
              placeholder="What specifically will be done by the end of Q3?"
              value={outcome}
              onChange={e => setOutcome(e.target.value)}
            />
            <p className="text-xs text-stone-500 mt-2 ml-1 flex items-center gap-1">
              <Compass size={12} /> Be specific. e.g. "Launch MVP to 50 users."
            </p>
          </div>
        </div>

        {/* Step 3: Key Tasks */}
        <div className="space-y-3">
           <label className="text-sm font-bold text-stone-900 uppercase tracking-wider flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-stone-900 text-white flex items-center justify-center text-xs">3</span>
            3-5 Key Actions
          </label>
          <div className="space-y-2">
            {tasks.map((task, idx) => (
              <div key={idx} className="flex items-center gap-3">
                <CheckCircle2 size={18} className="text-stone-300" />
                <input 
                  className="flex-1 p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-800 focus:outline-none"
                  placeholder={`Key Action ${idx + 1}`}
                  value={task}
                  onChange={e => handleTaskChange(idx, e.target.value)}
                />
              </div>
            ))}
            {tasks.length < 5 && (
              <button 
                onClick={() => setTasks([...tasks, ''])}
                className="text-sm text-emerald-700 font-medium hover:underline ml-8"
              >
                + Add another action
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="mt-12">
        {!canSubmit && (
           <div className="flex items-center gap-2 text-amber-600 bg-amber-50 p-3 rounded-lg mb-4 text-sm">
             <AlertCircle size={16} />
             <span>Complete all sections to lock your quarter plan.</span>
           </div>
        )}
        <button 
          onClick={handleSave}
          disabled={!canSubmit}
          className={`w-full py-4 rounded-xl font-bold text-lg transition-all ${
            !canSubmit
            ? 'bg-stone-200 text-stone-400 cursor-not-allowed' 
            : 'bg-emerald-800 text-white hover:bg-emerald-900 shadow-lg hover:shadow-xl'
          }`}
        >
          Commit to Quarter Plan
        </button>
      </div>
    </div>
  );
};