import React, { useState } from 'react';
import { QuarterPlan, DailyLog, EffortLevel } from '../types';
import { Briefcase, Zap, AlertTriangle } from 'lucide-react';

interface Props {
  quarterPlan: QuarterPlan;
  onLog: (log: Omit<DailyLog, 'id' | 'createdAt'>) => void;
  onCancel: () => void;
}

export const DailyLogForm: React.FC<Props> = ({ quarterPlan, onLog, onCancel }) => {
  const [description, setDescription] = useState('');
  const [isDistraction, setIsDistraction] = useState<boolean>(false);
  const [effort, setEffort] = useState<EffortLevel>('Medium');
  const [proactiveness, setProactiveness] = useState<number>(3);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) return;

    onLog({
      date: new Date().toISOString().split('T')[0],
      description,
      linkedQuarterGoalId: isDistraction ? null : quarterPlan.primaryGoalId,
      isDistraction,
      effort,
      proactiveness
    });
  };

  return (
    <div className="fixed inset-0 bg-stone-900/50 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="bg-stone-50 p-4 border-b border-stone-200 flex justify-between items-center">
          <h2 className="font-bold text-stone-900">Log Daily Work</h2>
          <button onClick={onCancel} className="text-stone-500 hover:text-stone-800 text-sm">Close</button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          
          {/* Question 1: What did you do? */}
          <div>
            <label className="block text-sm font-semibold text-stone-900 mb-2">What was your main focus today?</label>
            <textarea 
              autoFocus
              className="w-full p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-800 focus:outline-none resize-none h-24"
              placeholder="e.g., Drafted the API specification..."
              value={description}
              onChange={e => setDescription(e.target.value)}
            />
          </div>

          {/* Question 2: Alignment */}
          <div>
            <label className="block text-sm font-semibold text-stone-900 mb-2">Did this support your Q{quarterPlan.quarter} Goal?</label>
            <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-100 mb-3 text-sm text-emerald-900">
              <strong>Goal:</strong> {quarterPlan.outcome}
            </div>
            
            <div className="flex gap-3">
              <button 
                type="button"
                onClick={() => setIsDistraction(false)}
                className={`flex-1 py-3 px-4 rounded-lg border font-medium flex items-center justify-center gap-2 transition-all ${
                  !isDistraction 
                  ? 'bg-emerald-800 text-white border-emerald-800' 
                  : 'bg-white text-stone-500 border-stone-200 hover:bg-stone-50'
                }`}
              >
                <Briefcase size={18} /> Yes, Aligned
              </button>
              <button 
                type="button"
                onClick={() => setIsDistraction(true)}
                className={`flex-1 py-3 px-4 rounded-lg border font-medium flex items-center justify-center gap-2 transition-all ${
                  isDistraction 
                  ? 'bg-amber-600 text-white border-amber-600' 
                  : 'bg-white text-stone-500 border-stone-200 hover:bg-stone-50'
                }`}
              >
                <AlertTriangle size={18} /> Distraction
              </button>
            </div>
          </div>

          {/* Question 3: Effort Level */}
          <div>
            <label className="block text-sm font-semibold text-stone-900 mb-2">Effort Level</label>
            <div className="grid grid-cols-3 gap-2">
              {(['Low', 'Medium', 'Deep Work'] as EffortLevel[]).map(level => (
                <button
                  key={level}
                  type="button"
                  onClick={() => setEffort(level)}
                  className={`py-2 rounded-lg text-sm font-medium transition-all ${
                    effort === level 
                    ? 'bg-stone-800 text-white shadow-md' 
                    : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
                  }`}
                >
                  {level}
                </button>
              ))}
            </div>
          </div>

          {/* Question 4: Proactiveness */}
          <div>
            <label className="block text-sm font-semibold text-stone-900 mb-2">
              Proactiveness Score: <span className="text-emerald-700">{proactiveness}/5</span>
            </label>
            <input 
              type="range" 
              min="1" 
              max="5" 
              step="1"
              value={proactiveness}
              onChange={e => setProactiveness(parseInt(e.target.value))}
              className="w-full h-2 bg-stone-200 rounded-lg appearance-none cursor-pointer accent-emerald-800"
            />
            <div className="flex justify-between text-xs text-stone-400 mt-1">
              <span>Reactive</span>
              <span>Proactive</span>
            </div>
          </div>

          <button 
            type="submit"
            disabled={!description.trim()}
            className="w-full py-4 bg-emerald-800 text-white rounded-xl font-bold shadow-lg hover:bg-emerald-900 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Log Work
          </button>

        </form>
      </div>
    </div>
  );
};