import React, { useState } from 'react';
import { YearGoal } from '../types';
import { Plus, Target, Trash2 } from 'lucide-react';

interface Props {
  onSave: (goals: YearGoal[]) => void;
  existingGoals: YearGoal[];
}

export const YearGoalSetup: React.FC<Props> = ({ onSave, existingGoals }) => {
  const [goals, setGoals] = useState<YearGoal[]>(existingGoals);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  // Temporary form state
  const [title, setTitle] = useState('');
  const [why, setWhy] = useState('');
  const [criteria, setCriteria] = useState('');

  const handleAdd = () => {
    if (goals.length >= 3) return;
    setEditingId('new');
    setTitle('');
    setWhy('');
    setCriteria('');
  };

  const handleSaveGoal = () => {
    if (!title.trim()) return;
    
    const newGoal: YearGoal = {
      id: crypto.randomUUID(),
      title,
      why,
      successCriteria: criteria,
      createdAt: new Date().toISOString()
    };

    setGoals([...goals, newGoal]);
    setEditingId(null);
  };

  const handleDelete = (id: string) => {
    setGoals(goals.filter(g => g.id !== id));
  };

  const handleFinalize = () => {
    if (goals.length > 0) {
      onSave(goals);
    }
  };

  if (editingId === 'new') {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <h2 className="text-2xl font-bold text-stone-900 mb-6">Define a Year Goal</h2>
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Goal Title</label>
            <input 
              className="w-full p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-800 focus:outline-none"
              placeholder="e.g., Launch Personal SaaS Product"
              value={title}
              onChange={e => setTitle(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Why does this matter?</label>
            <textarea 
              className="w-full p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-800 focus:outline-none h-24"
              placeholder="This is my path to financial independence..."
              value={why}
              onChange={e => setWhy(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-stone-700 mb-1">Success Criteria (End of Year)</label>
            <textarea 
              className="w-full p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-emerald-800 focus:outline-none h-24"
              placeholder="100 paying customers, $5k MRR..."
              value={criteria}
              onChange={e => setCriteria(e.target.value)}
            />
          </div>
          <div className="flex gap-4 pt-4">
            <button 
              onClick={() => setEditingId(null)}
              className="px-6 py-2 text-stone-600 font-medium hover:bg-stone-100 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button 
              onClick={handleSaveGoal}
              className="flex-1 bg-emerald-800 text-white px-6 py-2 rounded-lg font-medium hover:bg-emerald-900 transition-colors"
            >
              Save Goal
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-2">
        <div className="mx-auto w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-800 mb-4">
          <Target size={24} />
        </div>
        <h1 className="text-3xl font-bold text-stone-900">Set Your Course</h1>
        <p className="text-stone-500 max-w-md mx-auto">
          Define up to 3 major goals for the year. Less is more. These will guide every quarter.
        </p>
      </div>

      <div className="space-y-4">
        {goals.map((goal, idx) => (
          <div key={goal.id} className="bg-white p-6 rounded-xl border border-stone-200 shadow-sm relative group">
            <button 
              onClick={() => handleDelete(goal.id)}
              className="absolute top-4 right-4 text-stone-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <Trash2 size={18} />
            </button>
            <h3 className="text-lg font-bold text-stone-900 mb-1">{idx + 1}. {goal.title}</h3>
            <p className="text-stone-600 text-sm mb-3">{goal.why}</p>
            <div className="bg-stone-50 p-3 rounded-lg text-xs text-stone-500">
              <span className="font-semibold text-stone-700">Success:</span> {goal.successCriteria}
            </div>
          </div>
        ))}

        {goals.length < 3 && (
          <button 
            onClick={handleAdd}
            className="w-full py-6 border-2 border-dashed border-stone-300 rounded-xl text-stone-500 hover:border-emerald-600 hover:text-emerald-700 transition-all flex items-center justify-center gap-2 font-medium"
          >
            <Plus size={20} />
            Add Year Goal
          </button>
        )}
      </div>

      <div className="pt-8 border-t border-stone-200">
        <button 
          onClick={handleFinalize}
          disabled={goals.length === 0}
          className={`w-full py-4 rounded-lg font-bold text-lg transition-all ${
            goals.length === 0 
            ? 'bg-stone-200 text-stone-400 cursor-not-allowed' 
            : 'bg-emerald-800 text-white hover:bg-emerald-900 shadow-lg hover:shadow-xl'
          }`}
        >
          {goals.length === 0 ? 'Add a Goal to Continue' : 'Lock Year Goals'}
        </button>
      </div>
    </div>
  );
};