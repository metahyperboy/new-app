import React, { useState } from 'react';
import { WeeklyReflection } from '../types';
import { Lightbulb, ArrowRight, X } from 'lucide-react';

interface Props {
  onSave: (reflection: Omit<WeeklyReflection, 'id' | 'createdAt'>) => void;
  onClose: () => void;
}

export const WeeklyReflectionForm: React.FC<Props> = ({ onSave, onClose }) => {
  const [step, setStep] = useState(1);
  const [movedForward, setMovedForward] = useState('');
  const [wastedTime, setWastedTime] = useState('');
  const [stopDoing, setStopDoing] = useState('');

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
    else handleSave();
  };

  const handleSave = () => {
    onSave({
      weekStartDate: new Date().toISOString().split('T')[0], // Approximation
      movedForward,
      wastedTime,
      stopDoing
    });
  };

  const getQuestion = () => {
    switch(step) {
      case 1: return "What specifically moved your Quarter Goal forward this week?";
      case 2: return "What wasted your time or caused distraction?";
      case 3: return "What is one thing you will STOP doing next week?";
      default: return "";
    }
  };

  const getValue = () => {
    switch(step) {
      case 1: return movedForward;
      case 2: return wastedTime;
      case 3: return stopDoing;
      default: return "";
    }
  };

  const setValue = (val: string) => {
    switch(step) {
      case 1: setMovedForward(val); break;
      case 2: setWastedTime(val); break;
      case 3: setStopDoing(val); break;
    }
  };

  return (
    <div className="fixed inset-0 bg-stone-900/80 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl relative overflow-hidden">
        <button onClick={onClose} className="absolute top-4 right-4 text-stone-400 hover:text-stone-800">
          <X size={24} />
        </button>

        <div className="bg-stone-50 p-8 text-center border-b border-stone-100">
           <div className="mx-auto w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center text-amber-600 mb-4">
            <Lightbulb size={24} />
           </div>
           <h2 className="text-xl font-bold text-stone-900">Weekly Reflection</h2>
           <p className="text-stone-500 text-sm mt-1">Step {step} of 3</p>
        </div>

        <div className="p-8">
          <label className="block text-lg font-medium text-stone-900 mb-4">
            {getQuestion()}
          </label>
          <textarea 
            autoFocus
            className="w-full p-4 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-none resize-none h-32 text-lg"
            placeholder="Type here..."
            value={getValue()}
            onChange={e => setValue(e.target.value)}
          />

          <div className="flex justify-between items-center mt-8">
            <div className="flex gap-1">
              {[1,2,3].map(s => (
                <div key={s} className={`h-1 w-8 rounded-full ${s <= step ? 'bg-amber-500' : 'bg-stone-200'}`} />
              ))}
            </div>
            <button 
              onClick={handleNext}
              disabled={!getValue().trim()}
              className="bg-stone-900 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-black transition-colors disabled:opacity-50"
            >
              {step === 3 ? 'Finish' : 'Next'} <ArrowRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};