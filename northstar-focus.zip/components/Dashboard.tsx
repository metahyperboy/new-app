import React, { useMemo } from 'react';
import { AppState, DailyLog, QuarterPlan, YearGoal } from '../types';
import { Flag, CheckCircle2, XCircle, TrendingUp, Calendar, ArrowRight, Zap } from 'lucide-react';
import { Area, AreaChart, ResponsiveContainer, Tooltip } from 'recharts';

interface Props {
  state: AppState;
  onOpenLog: () => void;
  onOpenReflect: () => void;
}

export const Dashboard: React.FC<Props> = ({ state, onOpenLog, onOpenReflect }) => {
  const currentQuarter = state.quarterPlans[state.quarterPlans.length - 1];
  const quarterGoal = state.yearGoals.find(g => g.id === currentQuarter?.primaryGoalId);

  // Compute Metrics
  const metrics = useMemo(() => {
    const logs = state.dailyLogs;
    if (logs.length === 0) return null;

    // Filter logs for current quarter time window ideally, but for simplicity taking all since creation
    const totalLogs = logs.length;
    const alignedLogs = logs.filter(l => !l.isDistraction).length;
    const alignmentScore = Math.round((alignedLogs / totalLogs) * 100);
    
    const deepWorkDays = logs.filter(l => l.effort === 'Deep Work').length;
    
    // Calculate Streak
    // Simplified streak logic: Consecutive days with at least one log
    const uniqueDates = Array.from(new Set(logs.map(l => l.date))).sort();
    let streak = 0;
    let current = new Date();
    // Very basic streak check for demo purposes
    streak = uniqueDates.length; 

    const avgProactiveness = (logs.reduce((acc, curr) => acc + curr.proactiveness, 0) / totalLogs).toFixed(1);

    return { alignmentScore, deepWorkDays, streak, avgProactiveness };
  }, [state.dailyLogs]);

  // Chart Data: Proactiveness over last 7 entries
  const chartData = useMemo(() => {
    return state.dailyLogs.slice(-7).map((log, i) => ({
      name: i,
      value: log.proactiveness
    }));
  }, [state.dailyLogs]);

  if (!currentQuarter) return null;

  return (
    <div className="space-y-8 pb-24">
      {/* Header */}
      <div>
        <div className="text-sm font-medium text-stone-400 uppercase tracking-widest mb-1">
          Current Focus (Q{currentQuarter.quarter})
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-stone-900 leading-tight">
          {currentQuarter.outcome}
        </h1>
        <div className="flex items-center gap-2 mt-2 text-stone-500 text-sm">
          <Flag size={14} className="text-emerald-700" />
          <span>Supports: {quarterGoal?.title}</span>
        </div>
        <div className="mt-4 h-1.5 w-full bg-stone-200 rounded-full overflow-hidden">
          <div 
            className="h-full bg-emerald-800 rounded-full transition-all duration-1000" 
            style={{ width: `${metrics ? metrics.alignmentScore : 0}%` }} 
          />
        </div>
        <div className="text-right text-xs text-stone-400 mt-1">
          {metrics ? metrics.alignmentScore : 0}% Alignment
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-start mb-2">
            <div className="p-2 bg-emerald-50 rounded-lg text-emerald-800">
               <TrendingUp size={20} />
            </div>
            {metrics && (
              <span className={`text-xs px-2 py-1 rounded-full ${metrics.alignmentScore > 70 ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                {metrics.alignmentScore > 70 ? 'On Track' : 'Drifting'}
              </span>
            )}
          </div>
          <div>
            <div className="text-3xl font-bold text-stone-900">{metrics?.alignmentScore || 0}%</div>
            <div className="text-xs text-stone-500 mt-1">Goal Alignment</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm flex flex-col justify-between">
           <div className="flex justify-between items-start mb-2">
            <div className="p-2 bg-stone-100 rounded-lg text-stone-800">
               <Zap size={20} />
            </div>
          </div>
          <div>
            <div className="text-3xl font-bold text-stone-900">{metrics?.deepWorkDays || 0}</div>
            <div className="text-xs text-stone-500 mt-1">Deep Work Sessions</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm flex flex-col justify-between">
           <div className="flex justify-between items-start mb-2">
            <div className="p-2 bg-stone-100 rounded-lg text-stone-800">
               <Calendar size={20} />
            </div>
          </div>
          <div>
            <div className="text-3xl font-bold text-stone-900">{metrics?.streak || 0}</div>
            <div className="text-xs text-stone-500 mt-1">Days Logged</div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-stone-100 shadow-sm flex flex-col justify-between relative overflow-hidden">
           <div className="absolute bottom-0 left-0 right-0 h-16 opacity-20 pointer-events-none">
             <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={chartData}>
                 <Area type="monotone" dataKey="value" stroke="#065f46" fill="#065f46" />
               </AreaChart>
             </ResponsiveContainer>
           </div>
           <div className="flex justify-between items-start mb-2 relative z-10">
            <div className="p-2 bg-stone-100 rounded-lg text-stone-800">
               <TrendingUp size={20} />
            </div>
          </div>
          <div className="relative z-10">
            <div className="text-3xl font-bold text-stone-900">{metrics?.avgProactiveness || 0}<span className="text-lg text-stone-400">/5</span></div>
            <div className="text-xs text-stone-500 mt-1">Proactiveness</div>
          </div>
        </div>
      </div>

      {/* Weekly Reflection Prompt */}
      <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-amber-200 w-2 h-2 rounded-full animate-pulse"></div>
          <span className="text-amber-900 font-medium text-sm">Weekly reflection is due</span>
        </div>
        <button 
          onClick={onOpenReflect}
          className="text-amber-900 text-xs font-bold uppercase tracking-wide flex items-center gap-1 hover:underline"
        >
          Start <ArrowRight size={12} />
        </button>
      </div>

      {/* Recent Activity List */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-stone-900">Recent Work</h3>
          <button className="text-emerald-700 text-sm font-medium hover:underline">View All</button>
        </div>
        <div className="space-y-3">
          {state.dailyLogs.slice().reverse().slice(0, 5).map(log => (
            <div key={log.id} className="bg-white p-4 rounded-xl border border-stone-100 shadow-sm flex gap-4">
              <div className={`mt-1 min-w-[24px] h-6 rounded-full flex items-center justify-center ${log.isDistraction ? 'bg-red-50 text-red-500' : 'bg-emerald-50 text-emerald-600'}`}>
                {log.isDistraction ? <XCircle size={16} /> : <CheckCircle2 size={16} />}
              </div>
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <h4 className="text-stone-900 font-medium text-sm leading-snug">{log.description}</h4>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium whitespace-nowrap ml-2 ${
                    log.effort === 'Deep Work' ? 'bg-indigo-50 text-indigo-700' :
                    log.effort === 'Medium' ? 'bg-stone-100 text-stone-600' :
                    'bg-stone-50 text-stone-400'
                  }`}>
                    {log.effort}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-2">
                   <div className="flex">
                     {[...Array(5)].map((_, i) => (
                       <div key={i} className={`w-2 h-2 rounded-full mr-1 ${i < log.proactiveness ? 'bg-amber-400' : 'bg-stone-200'}`} />
                     ))}
                   </div>
                   <span className="text-xs text-stone-400">{log.date}</span>
                </div>
              </div>
            </div>
          ))}
          {state.dailyLogs.length === 0 && (
             <div className="text-center py-10 text-stone-400 text-sm">
               No work logged yet. Start today strong.
             </div>
          )}
        </div>
      </div>

      {/* Floating Action Button */}
      <div className="fixed bottom-6 left-0 right-0 flex justify-center px-6 z-40 pointer-events-none">
        <button 
          onClick={onOpenLog}
          className="pointer-events-auto bg-stone-900 text-white shadow-2xl hover:bg-black transition-transform active:scale-95 flex items-center gap-3 px-8 py-4 rounded-full font-bold text-lg"
        >
          <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
          Log Today's Work
        </button>
      </div>
    </div>
  );
};