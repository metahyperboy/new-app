import { AppState, DailyLog, QuarterPlan, WeeklyReflection, YearGoal } from '../types';

const STORAGE_KEY = 'northstar_focus_data_v1';

const calculateInitialState = (): AppState => ({
  yearGoals: [],
  quarterPlans: [],
  dailyLogs: [],
  reflections: [],
});

export const loadState = (): AppState => {
  try {
    const serialized = localStorage.getItem(STORAGE_KEY);
    if (!serialized) return calculateInitialState();
    return JSON.parse(serialized);
  } catch (e) {
    console.error("Failed to load state", e);
    return calculateInitialState();
  }
};

export const saveState = (state: AppState) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.error("Failed to save state", e);
  }
};

// Helper to get current quarter info
export const getCurrentQuarter = () => {
  const date = new Date();
  const month = date.getMonth() + 1;
  const year = date.getFullYear();
  const quarter = Math.ceil(month / 3);
  return { year, quarter };
};
