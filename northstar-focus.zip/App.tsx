import React, { useEffect, useState } from 'react';
import { loadState, saveState } from './services/storage';
import { AppState, DailyLog, QuarterPlan, WeeklyReflection, YearGoal } from './types';
import { YearGoalSetup } from './components/YearGoalSetup';
import { QuarterSetup } from './components/QuarterSetup';
import { Dashboard } from './components/Dashboard';
import { DailyLogForm } from './components/DailyLogForm';
import { WeeklyReflectionForm } from './components/WeeklyReflectionForm';
import { Layout } from './components/Layout'; // We will inline layout if not separate, but let's separate
import { User, LogOut } from 'lucide-react';

const App: React.FC = () => {
  const [state, setState] = useState<AppState>({
    yearGoals: [],
    quarterPlans: [],
    dailyLogs: [],
    reflections: []
  });

  const [isLoading, setIsLoading] = useState(true);
  const [showLogForm, setShowLogForm] = useState(false);
  const [showReflectionForm, setShowReflectionForm] = useState(false);

  useEffect(() => {
    const loaded = loadState();
    setState(loaded);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    if (!isLoading) {
      saveState(state);
    }
  }, [state, isLoading]);

  const handleSaveYearGoals = (goals: YearGoal[]) => {
    setState(prev => ({ ...prev, yearGoals: goals }));
  };

  const handleSaveQuarterPlan = (plan: QuarterPlan) => {
    setState(prev => ({ ...prev, quarterPlans: [...prev.quarterPlans, plan] }));
  };

  const handleLogWork = (logData: Omit<DailyLog, 'id' | 'createdAt'>) => {
    const newLog: DailyLog = {
      ...logData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString()
    };
    setState(prev => ({ ...prev, dailyLogs: [...prev.dailyLogs, newLog] }));
    setShowLogForm(false);
  };

  const handleSaveReflection = (reflectionData: Omit<WeeklyReflection, 'id' | 'createdAt'>) => {
    const newReflection: WeeklyReflection = {
      ...reflectionData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString()
    };
    setState(prev => ({ ...prev, reflections: [...prev.reflections, newReflection] }));
    setShowReflectionForm(false);
  };

  const handleReset = () => {
    if(confirm("Are you sure you want to reset all data?")) {
      localStorage.clear();
      window.location.reload();
    }
  };

  if (isLoading) return <div className="h-screen flex items-center justify-center bg-stone-50">Loading...</div>;

  // View Routing Logic
  
  // 1. If no year goals, force setup
  if (state.yearGoals.length === 0) {
    return (
       <div className="min-h-screen bg-stone-50">
        <header className="p-6 flex justify-between items-center">
            <div className="font-bold text-xl text-stone-900 tracking-tight">NorthStar</div>
        </header>
        <YearGoalSetup existingGoals={[]} onSave={handleSaveYearGoals} />
       </div>
    );
  }

  // 2. If no quarter plan for current quarter (simplified check: just check if any exists for now), force setup
  // In a real app we would check date vs quarter plan date.
  if (state.quarterPlans.length === 0) {
    return (
       <div className="min-h-screen bg-stone-50">
         <header className="p-6 flex justify-between items-center">
            <div className="font-bold text-xl text-stone-900 tracking-tight">NorthStar</div>
        </header>
        <QuarterSetup yearGoals={state.yearGoals} onSave={handleSaveQuarterPlan} />
       </div>
    );
  }

  // 3. Main Dashboard
  const currentQuarter = state.quarterPlans[state.quarterPlans.length - 1];

  return (
    <div className="min-h-screen bg-stone-50 font-sans text-stone-900">
      <header className="bg-white border-b border-stone-200 sticky top-0 z-30">
        <div className="max-w-md mx-auto px-6 h-16 flex items-center justify-between">
          <div className="font-bold text-xl text-stone-900 tracking-tight flex items-center gap-2">
            <div className="w-3 h-3 bg-emerald-700 rounded-full"></div>
            NorthStar
          </div>
          <button onClick={handleReset} className="text-stone-400 hover:text-red-500 transition-colors">
            <LogOut size={18} />
          </button>
        </div>
      </header>

      <main className="max-w-md mx-auto p-6">
        <Dashboard 
          state={state} 
          onOpenLog={() => setShowLogForm(true)} 
          onOpenReflect={() => setShowReflectionForm(true)}
        />
      </main>

      {showLogForm && (
        <DailyLogForm 
          quarterPlan={currentQuarter} 
          onLog={handleLogWork} 
          onCancel={() => setShowLogForm(false)} 
        />
      )}

      {showReflectionForm && (
        <WeeklyReflectionForm 
          onSave={handleSaveReflection} 
          onClose={() => setShowReflectionForm(false)} 
        />
      )}
    </div>
  );
};

export default App;